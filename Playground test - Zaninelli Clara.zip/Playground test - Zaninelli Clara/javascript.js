/*Navabar Fixed*/ 
window.addEventListener("scroll", function(){
  var nav = this.document.querySelector("nav");
  nav.classList.toggle("sticky", window.scrollY > 0) ;
})

/*Slider Header*/ 
var slide = document.getElementById("slide");
        var images = new Array (
            "assets/images/slide-circle.jpg",
            "assets/images/slide-hello.jpg",
            "assets/images/slide-play.jpg"
        );

        var len = images.length;
        var i = 0;

        function slider(){
            if(i > len-1){
                i = 0;
            }
            slide.src = images[i];
            i++;
            setTimeout('slider()', 2000);
        
          }

